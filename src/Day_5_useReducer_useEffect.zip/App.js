import React, { useState } from "react";
import "./App.css";
import NoteAppPage from "./NoteApp";

export default function App() {
    return <NoteAppPage />
};
