import React, { useState } from "react";
import "./App.css";

export default function ComponentPosition() {
  const [name, setName] = useState("Mg Mg");

  const handleNextPerson = () => {
    const tempName = name === "Mg Mg" ? "John" : "Mg Mg";
    setName(tempName);
  };

  return (
    <div className="container justify-content-between d-flex mt-3">
      {name === "Mg Mg" ? (
        <Card name={name} handleNextPerson={handleNextPerson} key="1" />
      ) : (
        <Card name={name} handleNextPerson={handleNextPerson} key="2" />
      )}
    </div>
  );
}

// Lifting state up

// sharing data between components

//conditional rendering

//component state isolation

const Card = ({ name, handleNextPerson }) => {
  const [number, setNumber] = useState(0);
  return (
    <div className="card bg-primary col-3">
      <h1 className="text-white text-center mb-3">{name}</h1>
      <h1 className="text-white text-center">marks: {number}</h1>
      <button
        className="btn btn-warning btn-sm"
        onClick={() => setNumber(number + 1)}
      >
        Increment
      </button>
      <button className="btn btn-danger btn-sm mt-3" onClick={handleNextPerson}>
        Next
      </button>
    </div>
  );
};
