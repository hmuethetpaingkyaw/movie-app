import { useState } from "react";

export default function EditNoteForm({
  handleEdit,
  editInputValue,
  setEditInputValue,
  setEditId,
}) {
  return (
    <div className="d-flex gap-3 my-5">
      <input
        className="form-control"
        placeholder="Note"
        value={editInputValue}
        onChange={(event) => setEditInputValue(event.target.value)}
      />
      <button
        className="btn btn-warning"
        onClick={handleEdit}
      >
        Save
      </button>
      <button className="btn btn-danger" onClick={() => {
        setEditId(null);
        setEditInputValue(null)
      }}>
        Cancel
      </button>
    </div>
  );
}
