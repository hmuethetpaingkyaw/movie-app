import { useState } from "react";

export default function NewNoteForm({ handleAddNew, handleSave }) {
  const [inputValue, setInputValue] = useState("");

  return (
    <div className="d-flex gap-3 my-5">
      <input
        className="form-control"
        placeholder="Note"
        value={inputValue}
        onChange={(event) => setInputValue(event.target.value)}
      />
      <button className="btn btn-warning" onClick={() => handleSave(inputValue)}>
        Save
      </button>
      <button className="btn btn-danger" onClick={handleAddNew}>
        Cancel
      </button>
    </div>
  );
}
