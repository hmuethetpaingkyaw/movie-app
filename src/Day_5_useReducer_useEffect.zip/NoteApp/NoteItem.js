import { AiFillEdit, AiFillDelete } from "react-icons/ai";

export default function NoteItem({
  data,
  orderNumber,
  handleDelete,
  setEditId,
  setEditInputValue,
}) {
  return (
    <li className="text-decoration-none mb-3">
      <div className="d-flex gap-3">
        <h3
          className="text-white"
          style={{
            minWidth: "300px",
          }}
        >
          {" "}
          {orderNumber}. {data.note}
        </h3>
        <button
          className="btn btn-warning"
          onClick={() => {
            setEditId(data.id);
            setEditInputValue(data.note);
          }}
        >
          <AiFillEdit />
        </button>
        <button
          className="btn btn-danger"
          onClick={() => handleDelete(data.id)}
        >
          <AiFillDelete />
        </button>
      </div>
    </li>
  );
}
