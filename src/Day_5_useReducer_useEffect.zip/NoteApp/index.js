import { useEffect, useReducer, useState } from "react";
import { NoteData } from "../mock/data";
import { AiFillDelete } from "react-icons/ai";
import { useNote } from "../reducers/reducer.note";

export default function NoteAppPage() {
  const [data, setData] = useState(null)
  const [number, setNumber] = useState(null)

   useEffect(()=> {
    console.log("hello");
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then((res) => res.json())
      .then((result) => setData(result));
   }, [])

  // const [isAddNew, setIsAddNew] = useState(false);
  // const [inputValue, setInputValue] = useState("");

  // const { state, handleSave, handleDelete } = useNote();

  // const onSave = (inputValue) => {
  //   handleSave(inputValue)
  // };
  // const onDelete = (id) => {
  //   handleDelete(id)
  // };

  // const handleAddNew = () => {
  //   setIsAddNew(!isAddNew);
  // };

  if(!data) {
    return <h1>loading....</h1>
  }
  return (
    <div
      className="d-flex justify-content-center align-items-center bg-dark flex-column"
      style={{
        minHeight: "100vh",
      }}
    >
      {/* <button onClick={()=> setNumber(Math.random(100))}>Click</button> */}
      {/* {isAddNew ? (
        <div className="d-flex gap-3 my-5">
          <input
            className="form-control"
            placeholder="Note"
            onChange={(event) => setInputValue(event.target.value)}
          />
          <button
            className="btn btn-warning"
            onClick={() => onSave(inputValue)}
          >
            Save
          </button>
          <button className="btn btn-danger" onClick={handleAddNew}>
            Cancel
          </button>
        </div>
      ) : (
        <button className="btn btn-primary" onClick={handleAddNew}>
          Add New
        </button>
      )} */}
      <ul>
        {data?.map((item, index) => (
          <li className="text-decoration-none mb-3" key={index}>
            <div className="d-flex gap-3">
              <h3
                className="text-white"
                style={{
                  minWidth: "300px",
                }}
              >
                {" "}
                {index + 1}. {item.title}
              </h3>
              {/* <button
                className="btn btn-danger"
                onClick={() => onDelete(item.id)}
              >
                <AiFillDelete />
              </button> */}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
