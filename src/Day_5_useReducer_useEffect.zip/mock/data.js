

export const NoteData = [
  {
    id: 1,
    note: "Lifting state up",
  },
  {
    id: 2,
    note: "Sharing state",
  },
  {
    id: 3,
    note: "Component position",
  },
];