import { useReducer } from "react";
import { NoteData } from "../mock/data";

const reducer = (state, action) => {
  switch (action.type) {
    case "Delete":
      return state.filter((item) => item.id !== action.payload);
    case "Add":
      return [...state, { id: Math.random(1000), note: action.payload }];

    default:
      return state;
  }
};

//custom hook 
export function useNote () {
  const [state, dispatch] = useReducer(reducer, NoteData); //two parameters - reducer , initialState

  //dispatch function aceepts object called action
  const handleSave = (inputValue) => {
    dispatch({ type: "Add", payload: inputValue  });
  };
  const handleDelete = (id) => {
    dispatch({ type: "Delete", payload: id });
  };

  return {
    state,
    handleSave,
    handleDelete
  };
}